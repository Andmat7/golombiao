


$(window).load(function() {

	console.log("andres");


});
